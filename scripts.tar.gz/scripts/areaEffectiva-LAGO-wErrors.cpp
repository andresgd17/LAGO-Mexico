//---------------------------------------------------------------------------
// Fixed physical area for LAGO
//---------------------------------------------------------------------------

#include <iostream>
#include <string>
#include "TMath.h"
#include <TROOT.h>
#include "TH1F.h"
#include "TF1.h"
#include "TH2F.h"
#include "TTree.h"
#include "TFile.h"
#include "TChain.h"
#include "TCanvas.h"
#include "TGraph.h"
#include "TApplication.h"
#include "TPaveLabel.h"
#include "TPaveText.h"
#include <iostream>
#include <stdio.h>
#include <fstream>
#include <iomanip>
#include <sstream>


using namespace std;


int main(void) {

//---------------------------------------------------------------------------
// Setting input 
//---------------------------------------------------------------------------
 
  TObjArray Hlist(0);
  TApplication app("app",0,0);

//---------------------------------------------------------------------------
// Bines array and median bines array
//---------------------------------------------------------------------------
int nBin=25;
float xBin[25];
for (int i=0;i<=nBin;i++) {
  float loge=((float)i)*.172-.3;
  xBin[i]=pow(10.,loge);
 // cout << xBin[i]<< endl;
}

int mBines=2*nBin;
float prueba[51];
float mBin[25];
for (int i=0;i<=mBines;i++) {
  float loge=((float)i)*.086-.3;
  prueba[i]=pow(10.,loge);
 // cout << prueba[i]<< endl;
}

for (int i=0;i<=nBin;i++) {
  mBin[i] = prueba[i*2+1];

}
for (int i=0;i<=nBin;i++) {
  //cout <<i*2+1<<"	"<< i << "	"<< xBin[i]<<"	"<<mBin[i]<<endl;
}
//---------------------------------------------------------------------------
//  Open data file in a new tree
//---------------------------------------------------------------------------
  TFile *f =  new TFile("lagoreco-100files-radCorrected-new.root");

  TTree *events = (TTree*)f->Get("t2");
  ULong64_t nentries = (Int_t)events->GetEntries();

cout<<events->GetEntries()<<endl;

//---------------------------------------------------------------------------
//  Setting Branches and variables
//---------------------------------------------------------------------------
  Float_t energy;
  events->SetBranchAddress("pEnergy", &energy);
  Float_t area;
  events->SetBranchAddress("area", &area);
  ULong64_t nHit;
  events->SetBranchAddress("hits", &nHit);
  Float_t theta;
  events->SetBranchAddress("angleTheta",&theta);
//---------------------------------------------------------------------------
//  For loop to calculate variables for the effective area
//---------------------------------------------------------------------------
Int_t count[25][5];
Int_t nObs[25][5];
Float_t sumHits[25][5];
Float_t aEff[25][5];
Float_t aT[25][5];
Double_t errAEff[25][5];
Double_t hitWeight[25][5];
Double_t hitWeightPow[25][5];
Double_t hWPow;
Double_t hW;


for (Int_t angleBin = 1; angleBin <= 5; angleBin++){
    for (Int_t i=0;i<nBin;i++) { 
         count[i][angleBin] = 0;
         nObs[i][angleBin] = 0;
         sumHits[i][angleBin] = 0;
         aEff[i][angleBin] = 0;
         errAEff[i][angleBin]=0;
         hitWeight[i][angleBin]=0;
         hitWeightPow[i][angleBin]=0;
   }
}

for (ULong64_t j = 0 ; j < nentries ; j++){
    events->GetEntry(j);
  //  energy=energy/1000000000;			//no need to convert in GeV
  for (Int_t angleBin = 1; angleBin <= 5; angleBin++){ 
    if( acos(1.1-(Float_t)angleBin*0.1) <= theta && acos(1.0-(Float_t)angleBin*0.1) >= theta){
    for (Int_t i=0;i<nBin;i++) { 
        if (xBin[i]<=energy && xBin[i+1]>=energy){
           count[i][angleBin]=count[i][angleBin]+1;
           sumHits[i][angleBin]=sumHits[i][angleBin]+(Float_t)nHit;
           aT[i][angleBin] = area/10000;        //from cm² to m²
           hW=(Double_t)nHit * aT[i][angleBin]; //ratio is now = areaThrown
           hWPow=hW*hW;
           hitWeightPow[i][angleBin] = hitWeightPow[i][angleBin] + hWPow;
           if(nHit>=1.0){nObs[i][angleBin]=nObs[i][angleBin]+1.0;}



        }
    }
    }
  }
}





//---------------------------------------------------------------------------
//  For loop for the effective area with angle bines
//---------------------------------------------------------------------------
std::fstream outputFile1;
outputFile1.open("Bin1.dat",std::ios::out | std::ios::trunc);
std::fstream outputFile2;
outputFile2.open("Bin2.dat",std::ios::out | std::ios::trunc);
std::fstream outputFile3;
outputFile3.open("Bin3.dat",std::ios::out | std::ios::trunc);
std::fstream outputFile4;
outputFile4.open("Bin4.dat",std::ios::out | std::ios::trunc);
std::fstream outputFile5;
outputFile5.open("Bin5.dat",std::ios::out | std::ios::trunc);



  for (Int_t angleBin = 1; angleBin <= 5; angleBin++){ 
    for (Int_t i=0;i<nBin;i++) { 
    aEff[i][angleBin]=aT[i][angleBin]*sumHits[i][angleBin]/(count[i][angleBin]);
  errAEff[i][angleBin]=std::sqrt(hitWeightPow[i][angleBin]/((Double_t)count[i][angleBin]*(Double_t)count[i][angleBin]));
  cout<<count[i][angleBin]<<"	"<<sumHits[i][angleBin]<<"	"<<nObs[i][angleBin]<<"	"<<aEff[i][angleBin]<<"	"<<errAEff[i][angleBin]<<"	"<<i<<"	"<<angleBin<<endl;

  switch(angleBin){
                  case 1: 
                        outputFile1<<mBin[i]<<"	"<<aEff[i][angleBin]<<"	"<<xBin[i+1]/2-xBin[i]/2<<"	"<<  errAEff[i][angleBin]<<endl;
                        break;

                  case 2: 
                        outputFile2<<mBin[i]<<"	"<<aEff[i][angleBin]<<"	"<<xBin[i+1]/2-xBin[i]/2<<"	"<<  errAEff[i][angleBin]<<endl;
                        break;

                  case 3: 
                        outputFile3<<mBin[i]<<"	"<<aEff[i][angleBin]<<"	"<<xBin[i+1]/2-xBin[i]/2<<"	"<<  errAEff[i][angleBin]<<endl;
                        break;

                  case 4: 
                        outputFile4<<mBin[i]<<"	"<<aEff[i][angleBin]<<"	"<<xBin[i+1]/2-xBin[i]/2<<"	"<<  errAEff[i][angleBin]<<endl;
                        break;

                  case 5: 
                        outputFile5<<mBin[i]<<"	"<<aEff[i][angleBin]<<"	"<<xBin[i+1]/2-xBin[i]/2<<"	"<<  errAEff[i][angleBin]<<endl;
                        break;
                  
                   }

  }
}


  return 0;

}





