#!/bin/bash
echo ""
echo "Programa para generar los archivos binarios DATnnnnnn"
echo ""
echo "Introduce el numero total de archivos DATnnnn a generar en Corsika"
read count
declare -i x=100
declare -i y=200
declare -i z=300
declare -i t=50


echo "Corriendo simulaciones... espere..."
for i in `seq 1 $count`
do
touch lago
echo "RUNNR   $i                              run number" >> lago
echo "EVTNR   1                              number of first shower event" >> lago
echo "NSHOW   2                              number of showers to generate" >> lago
echo "PRMPAR  14                             particle type of prim. particle" >> lago
echo "ESLOPE  -2.7                           slope of primary energy spectrum" >> lago
echo "ERANGE  100.0 10.E3                   energy range of primary particle(GeV)" >> lago
echo "THETAP  0.  60.                         range of zenith angle (degree)" >> lago
echo "PHIP    0.  360.                    range of azimuth angle (degree)" >> lago
echo "SEED    $x 0 0                        seed for 1. random number sequence" >> lago
echo "SEED    $y 0 0                        seed for 2. random number sequence" >> lago
echo "SEED    $z 0 0                        seed for 3. random number sequence" >> lago
echo "QGSJET  T 0" >> lago
echo "QGSSIG  T" >> lago
echo "OBSLEV  4530.E2                        observation level (in cm)" >> lago
echo "FIXCHI  0.                             starting altitude (g/cm**2)" >> lago
echo "MAGNET  27.3689  29.3812               magnetic field centr. Europe" >> lago
echo "CSCAT   1  200000 200000" >> lago
echo "HADFLG  0  0  0  0  0  2               flags hadr.interact.&fragmentation" >> lago
echo "ECUTS   0.3  0.3  0.003  0.003         energy cuts for particles" >> lago
echo "MUADDI  T                              additional info for muons" >> lago
echo "MUMULT  T                              muon multiple scattering angle" >> lago
echo "ELMFLG  T   T                          em. interaction flags (NKG,EGS)" >> lago
echo "STEPFC  1.0                            mult. scattering step length fact." >> lago
echo "RADNKG  200.E2                         outer radius for NKG lat.dens.distr. " >> lago
echo "ARRANG  0." >> lago
echo "LONGI   T  20.  T  F                   longit.distr. & step size & fit & out" >> lago
echo "ECTMAP  1.E3                           cut on gamma factor for printout" >> lago
echo "MAXPRT  1                              max. number of printed events" >> lago
echo "DIRECT  /home/andres/Escritorio/corsika-75600/run/ " >> lago
echo "DATBAS  F" >> lago
echo "PAROUT  T  F ">> lago
echo "USER    andres                         user " >> lago
echo "DEBUG   F  6  F  1000000               debug flag and log.unit for out ">> lago
echo "EXIT                                   terminates input ">> lago

cd /home/andres/Escritorio/corsika-75600/run/
./corsika75600Linux_QGSJET_gheisha </home/andres/Escritorio/area-efectiva/lago> output.txt
echo ""
echo "Simulación numero $i realizada con exito"


if [ $i -le 999999 ] && [ $i -ge 100000 ]
then
dir="/home/andres/Escritorio/corsika-75600/run/DAT$i"
fi

if [ $i -le 99999 ] && [ $i -ge 10000 ]
then
dir="/home/andres/Escritorio/corsika-75600/run/DAT0$i"
fi

if [ $i -le 9999 ] && [ $i -ge 1000 ]
then
dir="/home/andres/Escritorio/corsika-75600/run/DAT00$i"
fi

if [ $i -le 999 ] && [ $i -ge 100 ]
then
dir="/home/andres/Escritorio/corsika-75600/run/DAT000$i"
fi

if [ $i -le 99 ] && [ $i -ge 10 ]
then
dir="/home/andres/Escritorio/corsika-75600/run/DAT0000$i"
fi

if [ $i -le 9 ]
then
dir="/home/andres/Escritorio/corsika-75600/run/DAT00000$i"
fi

gzip $dir


if [ $i -le 999999 ] && [ $i -ge 100000 ]
then
rm DAT$i
rm CER$i
fi

if [ $i -le 99999 ] && [ $i -ge 10000 ]
then
rm DAT0$i
rm CER0$i
fi

if [ $i -le 9999 ] && [ $i -ge 1000 ]
then
rm DAT00$i
rm CER00$i
fi

if [ $i -le 999 ] && [ $i -ge 100 ]
then
rm DAT000$i
rm CER000$i
fi

if [ $i -le 99 ] && [ $i -ge 10 ]
then
rm DAT0000$i
rm CER0000$i
fi

if [ $i -le 9 ]
then
rm DAT00000$i
rm CER00000$i
fi

cd /home/andres/Escritorio/area-efectiva/
rm lago

x=$(( x + t ))
y=$(( y + t ))
z=$(( z + t ))

echo "$x y $y y $z"

done

exit
