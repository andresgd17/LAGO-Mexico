#!/bin/bash
echo ""
echo "Programa para obtener las carpetas con los chubascos"

for i in `seq 1 100`
do

cd /home/andres/Escritorio/corsika-75600/run

if [ $i -le 999999 ] && [ $i -ge 100000 ]
then
dir="/home/andres/Escritorio/corsika-75600/run/DAT$i"
fi

if [ $i -le 99999 ] && [ $i -ge 10000 ]
then
dir="/home/andres/Escritorio/corsika-75600/run/DAT0$i"
fi

if [ $i -le 9999 ] && [ $i -ge 1000 ]
then
dir="/home/andres/Escritorio/corsika-75600/run/DAT00$i"
fi

if [ $i -le 999 ] && [ $i -ge 100 ]
then
dir="/home/andres/Escritorio/corsika-75600/run/DAT000$i"
fi

if [ $i -le 99 ] && [ $i -ge 10 ]
then
dir="/home/andres/Escritorio/corsika-75600/run/DAT0000$i"
fi

if [ $i -le 9 ]
then
dir="/home/andres/Escritorio/corsika-75600/run/DAT00000$i"
fi

gunzip $dir

touch input  ## input se crea en run

if [ $i -le 999999 ] && [ $i -ge 100000 ]
then
echo "/home/andres/Escritorio/corsika-75600/run/DAT$i" > input
fi

if [ $i -le 99999 ] && [ $i -ge 10000 ]
then
echo "/home/andres/Escritorio/corsika-75600/run/DAT0$i" > input
fi

if [ $i -le 9999 ] && [ $i -ge 1000 ]
then
echo "/home/andres/Escritorio/corsika-75600/run/DAT00$i" > input
fi

if [ $i -le 999 ] && [ $i -ge 100 ]
then
echo "/home/andres/Escritorio/corsika-75600/run/DAT000$i" > input
fi

if [ $i -le 99 ] && [ $i -ge 10 ]
then
echo "/home/andres/Escritorio/corsika-75600/run/DAT0000$i" > input
fi

if [ $i -le 9 ]
then
echo "/home/andres/Escritorio/corsika-75600/run/DAT00000$i" > input
fi

./corsikaread <input
mkdir /home/andres/Escritorio/binarios/dat$i
mv fort.7 /home/andres/Escritorio/binarios/dat$i
cp /home/andres/Escritorio/calculo_n_archivos /home/andres/Escritorio/binarios/dat$i

cd /home/andres/Escritorio/binarios/dat$i

./calculo_n_archivos

cd /home/andres/Escritorio/corsika-75600/run

gzip $dir

done
exit
