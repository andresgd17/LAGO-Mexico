//Programa que transforma los fotones que llegan a ser detectados en GEANT4 por los PMTs en Hits para LAGO.
//Es necesario contar con los archivos de curvas para poder asociar la posición con una cantidad de carga.

//---------------------------------------------------------------------------
// Fixed physical area for LAGO
//---------------------------------------------------------------------------

#include <iostream>
#include <string>
#include "TMath.h"
#include <TROOT.h>
#include "TH1F.h"
//#include "TNtuple.h"
#include "TF1.h"
#include "TH2F.h"
#include "TTree.h"
#include "TFile.h"
#include "TChain.h"
#include "TCanvas.h"
#include "TGraph.h"
#include "TApplication.h"
#include "TPaveLabel.h"
#include "TPaveText.h"
#include <iostream>
#include <stdio.h>
#include <fstream>
#include <iomanip>
#include <sstream>
#include <TRandom3.h>

using namespace std;


int main(void) {

//---------------------------------------------------------------------------
// Setting input 
//---------------------------------------------------------------------------
 
  TObjArray Hlist(0);
  TApplication app("app",0,0);


//---------------------------------------------------------------------------
//  Open data file in a new tree
//---------------------------------------------------------------------------

//¡¡¡¡¡¡¡¡¡¡¡¡¡¡¡INPUT FILE!!!!!!!!!!!!!!!!!!!
  TFile *f = new TFile("lago-100files.root","READONLY");
  TTree *events = (TTree*)f->Get("T");
  ULong64_t nentries = (Int_t)events->GetEntries();

////cout<<events->GetEntries()<<endl;

//---------------------------------------------------------------------------
//  Setting Branches and variables
//---------------------------------------------------------------------------
  Float_t energy;
  events->SetBranchAddress("ePrimary", &energy);
  Float_t Area;
  events->SetBranchAddress("area", &Area);
  Float_t Theta;
  events->SetBranchAddress("theta",&Theta);
  Float_t Phi;
  events->SetBranchAddress("phi",&Phi);
  Float_t xC;
  events->SetBranchAddress("xCore",&xC);
  Float_t yC;
  events->SetBranchAddress("yCore",&yC);
  Float_t cPMT;
  events->SetBranchAddress("codePMT",&cPMT);
  Float_t dRad;
  events->SetBranchAddress("dRadius",&dRad);

//---------------------------------------------------------------------------
//  Variables
//---------------------------------------------------------------------------

TRandom *r = new TRandom3(0);
Double_t x;
Float_t a, b, charge=0;
Float_t sumCharge110=0, sumCharge111=0, sumCharge112=0, sumCharge113=0;
Float_t sumCharge210=0, sumCharge211=0, sumCharge212=0, sumCharge213=0;
Float_t sumCharge310=0, sumCharge311=0, sumCharge312=0, sumCharge313=0;
Float_t energyAnt=0, thetaAnt=0, phiAnt=0, xcAnt=0, ycAnt=0;
//¡¡¡¡¡¡¡¡¡¡¡¡¡¡¡¡¡¡¡ATENCION!!!!!!!!!!!!!!!!!!!!!!!
//Aquí se fija el tamaño del nHit de LAGO!!!!!!!!!!!
//******************
   Float_t nHitLAGO=0.333; //en fotoelectrones
//******************
Float_t PE110;
Float_t PE111;
Float_t PE112;
Float_t PE113;

Float_t PE210;
Float_t PE211;
Float_t PE212;
Float_t PE213;

Float_t PE310;
Float_t PE311;
Float_t PE312;
Float_t PE313;

Long_t totalHits = 0;
//---------------------------------------------------------------------------
//Create a tree 
//---------------------------------------------------------------------------

//!!!!!!!!!!!!!!!!!OUTPUT FILE!!!!!!!!!!!!!!!!!!!!!!1
TFile *f1 = new TFile("lagoreco-100files-radCorrected-new.root","recreate");
//TFile *f1 = new TFile("lagoreco-anterior.root","recreate");
TTree *t2 = new TTree("t2","Reconstruction of LAGO simulations");
t2->Branch("area",&Area,"Area/F");
t2->Branch("pEnergy",&energyAnt,"pEnergy/F");
t2->Branch("angleTheta",&thetaAnt,"Theta/F");
t2->Branch("anglePhi",&phiAnt,"Phi/F");
t2->Branch("xCore",&xcAnt,"xC/F");
t2->Branch("yCore",&ycAnt,"yC/F");
t2->Branch("hits",&totalHits,"totalHits/l");


//---------------------------------------------------------------------------
//  Read the distance and obtain an amount of charge from the random numbers 
//  and tables, curvesx.dat-HAWC curves from pe-curves.dat & curvesx-LAGO.dat 
//  curves resized for LAGO
//---------------------------------------------------------------------------
    ifstream FILE0("curves0.dat",ios::in);
    ifstream FILE1("curves1.dat",ios::in);
    ifstream FILE2("curves2.dat",ios::in);
    ifstream FILE3("curves3.dat",ios::in);
    ifstream FILE4("curves4.dat",ios::in);
    ifstream FILE5("curves5.dat",ios::in);
    ifstream FILE6("curves6.dat",ios::in);

for (ULong64_t i = 0 ; i < nentries ; i++){

    events->GetEntry(i);

    if ((energy==energyAnt)){   //Same shower!!!!!

    x = r->Rndm(i);                         //Just generate random numbers if there are detected photons


       if ((dRad<=3.85)){////cout<<"primer radio "<<x<<endl;           //First radius
          while (FILE0>>a>>b){
                ////cout<<a<<" "<<b<<endl; 
                if (x<a)
                   {
                   charge = b;
                   //cout<< charge <<" "<<cPMT<<" "<<dRad<<" "<<i<<" "<<energy<<" "<<energyAnt<<endl;
                   break;
                }
          }FILE0.seekg(0, ios::beg);
       }
       if ((dRad>3.85) && (dRad<=6.7)){           //Second radius
          while (FILE1>>a>>b){

                if (x<a)
                   {
                   charge = b;
                   break;
                }
          }FILE1.seekg(0, ios::beg);
       }
       if ((dRad>6.7) && (dRad<=7.9)){          //Third radius
          while (FILE2>>a>>b){

                if (x<a)
                   {
                   charge = b;
                   break;
                }
          }FILE2.seekg(0, ios::beg);
       }
       if ((dRad>7.9) && (dRad<=8.4)){           //Fourth radius
          while (FILE3>>a>>b){

                if (x<a)
                   {
                   charge = b;
                   break;
                }
          }FILE3.seekg(0, ios::beg);
       }
       if ((dRad>8.4) && (dRad<=8.6)){          //Fiveth radius
          while (FILE4>>a>>b){

                if (x<a)
                   {
                   charge = b;
                   break;
                }
          }FILE4.seekg(0, ios::beg);
       }
       if ((dRad>8.6) && (dRad<=9.8)){          //sixth radius
          while (FILE5>>a>>b){

                if (x<a)
                   {
                   charge = b;
                   break;
                }
          }FILE5.seekg(0, ios::beg);
       }
       if ((dRad>9.8)){// && (dRad<10.15)){         //Seventh radius
          while (FILE6>>a>>b){
                if (x<a)
                   {
                   charge = b;
                   break;
                }
          }FILE6.seekg(0, ios::beg);
       }
    // sum of the charge for each PMT
    switch ((Int_t) cPMT){
                  case 110: sumCharge110 = sumCharge110 + charge; break;
                  case 111: sumCharge111 = sumCharge111 + charge; break;
                  case 112: sumCharge112 = sumCharge112 + charge; break;
                  case 113: sumCharge113 = sumCharge113 + charge; break;
                  case 210: sumCharge210 = sumCharge210 + charge; break;
                  case 211: sumCharge211 = sumCharge211 + charge; break;
                  case 212: sumCharge212 = sumCharge212 + charge; break;
                  case 213: sumCharge213 = sumCharge213 + charge; break;
                  case 310: sumCharge310 = sumCharge310 + charge; break;
                  case 311: sumCharge311 = sumCharge311 + charge; break;
                  case 312: sumCharge312 = sumCharge312 + charge; break;
                  case 313: sumCharge313 = sumCharge313 + charge; break;
    }

    PE110 = sumCharge110/nHitLAGO;
    PE111 = sumCharge111/nHitLAGO;
    PE112 = sumCharge112/nHitLAGO;
    PE113 = sumCharge113/nHitLAGO;

    PE210 = sumCharge210/nHitLAGO;
    PE211 = sumCharge211/nHitLAGO;
    PE212 = sumCharge212/nHitLAGO;
    PE213 = sumCharge213/nHitLAGO;

    PE310 = sumCharge310/nHitLAGO;
    PE311 = sumCharge311/nHitLAGO;
    PE312 = sumCharge312/nHitLAGO;
    PE313 = sumCharge313/nHitLAGO;

    //cout<<sumCharge110<<" "<<PE110<<" "<<(Long_t) PE110<<endl;
    //cout<<sumCharge112<<" "<<PE112<<" "<<(Long_t) PE112<<endl;

    totalHits = (Long_t) PE110 + (Long_t) PE111 + (Long_t) PE112 + (Long_t) PE113 + (Long_t) PE210 + (Long_t) PE211 + (Long_t) PE212 + (Long_t) PE213 + (Long_t) PE310 + (Long_t) PE311 + (Long_t) PE312 + (Long_t) PE313;
    
    //cout<<totalHits<<endl;
    
    }//same shower end
    

    if ((energy!=energyAnt) && (cPMT==0)){ // restart the counts for every different shower
    //cout<<Area<<" "<<energyAnt<<" "<<thetaAnt<<" "<<phiAnt<<" "<<xcAnt<<" "<<ycAnt<<" "<<totalHits<<endl;
    // Fill tree
    t2->Fill();
    sumCharge110=0; sumCharge111=0; sumCharge112=0; sumCharge113=0;
    sumCharge210=0; sumCharge211=0; sumCharge212=0; sumCharge213=0;
    sumCharge310=0; sumCharge311=0; sumCharge312=0; sumCharge313=0;
    totalHits = 0;
    }

 
    energyAnt=energy;
    thetaAnt=Theta;
    phiAnt=Phi;
    xcAnt=xC;
    ycAnt=yC;
}

t2->Write();

return 0;

}
