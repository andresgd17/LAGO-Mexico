#!/bin/bash
echo ""
echo "Programa que corre GEANT4 con los archivos de las carpetas dat(N)"
echo ""

source /home/andres/Escritorio/GEANT4/geant4.10.01.p03-install/bin/geant4.sh 

for j in `seq 1 3`
do
carpeta=""
carpeta="/home/andres/Escritorio/binarios/dat$j"

for k in `seq 1 2`
do
cd $carpeta
archivo=""
archivo="ya$k.dat"

output=$( wc -l $archivo)
numero=${output:0:2}

cp $archivo ya.dat
mv ya.dat /home/andres/Escritorio/Lago-build/
cd /home/andres/Escritorio/Lago-build/

if (( numero <= 1 ))
then 
  ./noprocesa
fi

if (( numero > 1 ))
then
  ./OpNovice -m geometry.mac
fi


done

dato=""
dato="dato$j.dat"
mv dato.dat /home/andres/Escritorio/$dato
done
exit
